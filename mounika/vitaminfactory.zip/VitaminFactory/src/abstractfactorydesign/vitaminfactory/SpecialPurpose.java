package abstractfactorydesign.vitaminfactory;

public class SpecialPurpose implements Dosage {

	@Override
	public String getDose() {
		return "Special Purpose";
	}

}
