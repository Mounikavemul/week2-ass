package abstractfactorydesign.vitaminfactory;

public interface Dosage {
   public String getDose();
}
