package abstractfactorydesign.vitaminfactory;

public class Adults implements UserType{

	@Override
	public String getUser() {
		return "Used for Adults";
	}

}