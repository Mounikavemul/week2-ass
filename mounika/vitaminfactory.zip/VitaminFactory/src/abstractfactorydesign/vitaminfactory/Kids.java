package abstractfactorydesign.vitaminfactory;

public class Kids implements UserType{

	@Override
	public String getUser() {
		return "Used for Kids";
	}

}
