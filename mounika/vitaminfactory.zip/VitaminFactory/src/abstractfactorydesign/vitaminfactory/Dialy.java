package abstractfactorydesign.vitaminfactory;

public class Dialy implements Dosage {

	@Override
	public String getDose() {
		return "Dialy";
	}

}
