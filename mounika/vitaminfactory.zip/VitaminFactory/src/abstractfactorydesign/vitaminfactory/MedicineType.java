package abstractfactorydesign.vitaminfactory;

public interface MedicineType {
  public String getForm();
}
