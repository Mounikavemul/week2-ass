package abstractfactorydesign.vitaminfactory;

public interface UserType {
    public String getUser();
}
