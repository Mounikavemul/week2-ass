package abstractfactorydesign.vitaminfactory;

public class Chewables implements MedicineType {

	@Override
	public String getForm() {
		return "Chewables";
	}

}
